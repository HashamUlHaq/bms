from sparknlp.annotator import *
from sparknlp_jsl.annotator import *
from sparknlp.base import *
import math
import pandas as pd
from pyspark.sql import Row
from ctdi_treatment.resolver_pipeline import ResolverPipeline


pair_nd = ["strength","duration","frequency","dosage","route","form",
                           "relativedate","administration","cyclelength"]
pair_dr = ['drug', 'treatment']
pairs = [ f'{j}-{i}' for i in pair_nd for j in pair_dr]
pairs += [ i.split('-')[1]+'-'+i.split('-')[0] for i in pairs ]


class TreatmentPipeline():
    
    def __init__(self, spark):
        """
            spark: spark context to create a pipeline
        """
        
        self.spark = spark

        documenter = DocumentAssembler().setInputCol("text").setOutputCol("document")

        sentencer = SentenceDetectorDLModel.pretrained("sentence_detector_dl_healthcare","en","clinical/models")\
            .setInputCols(["document"]) \
            .setOutputCol("sentence")
        #sentencer = SentenceDetector().setCustomBounds(["\r\n","\n","\r",": ","; ","\. "])\
        #    .setInputCols(["document"]) \
        #    .setOutputCol("sentence")

        tokenizer = Tokenizer().setInputCols("sentence").setOutputCol("token")

        embeddings = WordEmbeddingsModel.pretrained("embeddings_clinical", "en", "clinical/models").setOutputCol("embs")

        pos = PerceptronModel().pretrained("pos_clinical", "en", "clinical/models") \
            .setInputCols(["sentence", "token"]).setOutputCol("pos_tags")
        
        dependency_parser = DependencyParserModel()\
            .pretrained("dependency_conllu", "en")\
            .setInputCols(["sentence", "pos_tags", "token"])\
            .setOutputCol("dependencies")

        ner_pos = MedicalNerModel.pretrained('ner_posology_experimental', 'en', 'clinical/models')\
            .setInputCols(['token', 'sentence', 'embs']).setOutputCol('ner_pos')
        
        ner_pos_conv = NerConverterInternal().setInputCols("sentence","token", 'ner_pos').setOutputCol("ner_pos_chunk")
        
        
        ner_clinical = MedicalNerModel.pretrained('ner_clinical_large', "en", "clinical/models")\
            .setInputCols(['token', 'sentence', 'embs']).setOutputCol('ner_clinical')
        
        ner_clinical_conv = NerConverterInternal().setInputCols(["sentence","token", 'ner_clinical'])\
            .setOutputCol("ner_clinical_chunk").setWhiteList(['TREATMENT'])

        
        ner_jsl = MedicalNerModel.pretrained('ner_jsl_greedy', "en", "clinical/models")\
            .setInputCols(['token', 'sentence', 'embs']).setOutputCol('ner_jsl')
        
        ner_jsl_conv = NerConverterInternal().setInputCols(["sentence","token", 'ner_jsl'])\
            .setOutputCol("ner_jsl_chunk").setWhiteList(['TREATMENT'])

        
        cm_trtment = ChunkMergeApproach().setInputCols("ner_jsl_chunk","ner_clinical_chunk").setOutputCol("chunk_treatment")\
            .setMergeOverlapping(True)

        cm_drug_treatment = ChunkMergeApproach().setInputCols("ner_pos_chunk", "chunk_treatment").setOutputCol("full_chunk")\
            .setMergeOverlapping(True)

        assertion = AssertionDLModel.pretrained("assertion_dl", "en", "clinical/models") \
            .setInputCols(["sentence", "chunk_treatment", "embs"]) \
            .setOutputCol("assertion")    
    
        posology_re = RelationExtractionModel()\
            .pretrained("posology_re")\
            .setInputCols(["embs", "pos_tags", "full_chunk", "dependencies"])\
            .setOutputCol("relations")\
            .setMaxSyntacticDistance(5)\
            .setRelationPairs(pairs)

        pipeline = Pipeline().setStages([
            documenter, sentencer, tokenizer, embeddings, pos, dependency_parser, 
            ner_pos, ner_pos_conv,
            ner_clinical, ner_clinical_conv,
            ner_jsl, ner_jsl_conv,
            cm_trtment,
            cm_drug_treatment,
            assertion,
            posology_re
        ])
        
        self.p_model = pipeline.fit(self.spark.createDataFrame([("",)]).toDF("text"))
        self.l_model = LightPipeline(self.p_model)
        
        print ('Main Pipeline Created...')
        
        self.resolver_pipeline = ResolverPipeline(self.spark)
        
        print ('Resolver Pipeline Loaded...')

    def run_light(self, text_list):
        """
            text_list: list of notes to run through the pipeline
        """
        
        return self.l_model.fullAnnotate(text_list)
    
    def run_full(self, text_list):
        """
            text_list: list of notes to run through the pipeline
        """
        
        return self.p_model.transform(self.spark.createDataFrame(pd.DataFrame({'text': text_list}))).collect()
    
    def run_only_resolver(self, text_list):
        """
            text_list: list of notes to run through the pipeline
        """
        
        return self.resolver_pipeline.resolve_full(list(mapping_dict.keys()))
    
    def run_with_resolver_smart(self, text_list):
        """
            text_list: list of notes to run through the pipeline
        """
        
        print ('Running full solution smartly...')
        
        ner_results = self.run_full(text_list)
        
        print ('Ner Pipeline Executed...')
        
        print ('Preparing Data for Resolvers...')
        
        drugs_list = []
        for row_ind, row in enumerate(ner_results):
            for entity_id, entity in enumerate(row['full_chunk']):
                if entity.metadata['entity'].lower().strip() == 'drug':
                    drugs_list.append( {'example_no': row_ind, 
                                        'entity_id': entity_id, 
                                        'begin' : int(entity.begin),
                                        'end' : int(entity.end),
                                        'chunk' : entity.result.strip().lower() })
        
        mapping_dict = {}
        drugs_df = pd.DataFrame(drugs_list)
        
        for index, group in drugs_df.groupby('chunk'):
            mapping_dict[index] = []
            for i, row in group.iterrows():
                mapping_dict[index].append( {'example_no' : row['example_no'], 
                                             'begin' : row['begin'],
                                                'end' : row['end'],
                                             'entity_id' : row['entity_id']} )
                
        print ('Data Prepared for Resolvers...')
        
        print ('Executing Resolver Pipeline...')
        
        basic_resolver_results = self.resolver_pipeline.resolve_full(list(mapping_dict.keys()))
        
        print ('Resolver Pipeline Executed...')
        
        print ('Preparing Full Result...')
           
        resolver_results = [ [] for i in range(len(ner_results))]
        for row in basic_resolver_results:
            for map_ent in mapping_dict[row['text']]:
                temp = row['resolution_rxnorm'][0].asDict()
                temp['begin'] = map_ent['begin']
                temp['end'] = map_ent['end']
                resolver_results[map_ent['example_no']].append(Row(**temp))
                
        assert len(resolver_results) == len(ner_results) 
        
        combined_res = []
        for res_res, row in zip(resolver_results, ner_results):
            temp = row.asDict()
            temp["resolution_rxnorm"] = res_res
            combined_res.append(Row(**temp))
        
        
        print ('Result Mapped and Ready...')
        
        return combined_res
    
    