from sparknlp.annotator import *
from sparknlp_jsl.annotator import *
from sparknlp.base import *
import math
import pandas as pd


class ResolverPipeline():
    
    def __init__(self, spark):
        """
            spark: spark context to create a pipeline
        """
        
        documenter = DocumentAssembler().setInputCol('text').setOutputCol('document')

        sbert = BertSentenceEmbeddings.pretrained("sbiobert_base_cased_mli","en","clinical/models")\
            .setInputCols("document").setOutputCol("sbert_embeddings_sbert")

        rxnorm = SentenceEntityResolverModel.pretrained("sbiobertresolve_rxnorm_disposition","en","clinical/models")\
            .setInputCols(f"document","sbert_embeddings_sbert").setOutputCol("resolution_rxnorm")#.setNeighbours(3)

        pipeline = Pipeline().setStages([
            documenter, sbert, rxnorm
        ])

        self.spark = spark
        self.p_model = pipeline.fit(self.spark.createDataFrame([("",)]).toDF("text"))
        self.l_model = LightPipeline(self.p_model)
        
    def resolve_light(self, text_list):
        """
            text_list: list of text/names of drugs to run through the pipeline
        """
        return self.l_model.fullAnnotate(text_list)
    
    def resolve_full(self, text_list):
        """
            text_list: list of text/names of drugs to run through the pipeline
        """
        
        to_process = self.spark.createDataFrame(pd.DataFrame({'text' : text_list}))
        res = self.p_model.transform(to_process).collect()
        return res
    